import numpy as np

# given array
arr = np.array([[10, 20, 30],
                [40, 50, 60],
                [70, 80, 90]])

# second row
print("Second row:", arr[1])

# third column
print("Third column:", arr[:, 2])

# submatrix (first 2 rows and columns)
print("Submatrix:\n", arr[:2, :2])
