import numpy as np

# create array from 10 to 19
arr = np.arange(10, 20)

# print outputs
print("Array:", arr)
print("Shape:", arr.shape)
print("Dimensions:", arr.ndim)
print("Data type:", arr.dtype)
