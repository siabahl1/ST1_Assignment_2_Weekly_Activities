import numpy as np

# create 3x3 matrix (1 to 9)
matrix = np.arange(1, 10).reshape(3, 3)

# create 1D array
arr = np.array([1, 0, -1])

# broadcasting multiplication
result = matrix * arr

# print results
print("Matrix:\n", matrix)
print("Array:", arr)
print("Result:\n", result)
