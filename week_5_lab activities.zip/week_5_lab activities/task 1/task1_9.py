import numpy as np

# given 3D array
temps = np.array([
    [[10, 15, 20], [25, 30, 35]],
    [[11, 16, 21], [26, 31, 36]]
])

# extract second location (index 1 in second dimension)
result = temps[:, 1, :]

# print result
print(result)
