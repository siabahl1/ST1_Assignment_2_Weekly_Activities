import numpy as np

# given arrays
a = np.array([5, 10, 15])
b = np.array([2, 4, 6])

# operations
print("Sum:", a + b)
print("Difference:", a - b)
print("Product:", a * b)
print("Division:", a / b)
