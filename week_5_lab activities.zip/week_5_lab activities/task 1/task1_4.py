import numpy as np

# create 3D array of ones
arr = np.ones((2, 2, 3), dtype=int)

# assign value 5 to position [1, 0, 2]
arr[1, 0, 2] = 5

# print result
print(arr)
