import numpy as np

# create array
arr = np.array([2, 4, 6, 8, 10])

# print every other element starting from first
print(arr[::2])
