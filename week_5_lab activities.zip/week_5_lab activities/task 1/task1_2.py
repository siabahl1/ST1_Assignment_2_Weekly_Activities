import numpy as np

# create 3x3 array of zeros
arr = np.zeros((3, 3), dtype=int)

# replace centre element with 7
arr[1, 1] = 7

# print result
print(arr)
