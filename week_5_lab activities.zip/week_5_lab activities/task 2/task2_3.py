import cv2

# load image
image = cv2.imread('/Users/siabahl/Desktop/Assets/Insects/1_Gammar 2021_1_2021_06_03-13-19-23-879.PNG')

# resize image to 400x300
resized = cv2.resize(image, (400, 300))

# show resized image
cv2.imshow("Resized Image", resized)

cv2.waitKey(0)
cv2.destroyAllWindows()
