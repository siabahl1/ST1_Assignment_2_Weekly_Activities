import cv2

# load image
image = cv2.imread('/Users/siabahl/Desktop/Assets/Insects/1_Gammar 2021_1_2021_06_03-13-19-23-879.PNG')

# get pixel value at (50, 50)
pixel = image[50, 50]
print("Original pixel value:", pixel)

# change pixel to white
image[50, 50] = [255, 255, 255]

# save modified image
cv2.imwrite('modified.png', image)

# show image
cv2.imshow("Modified Image", image)

cv2.waitKey(0)
cv2.destroyAllWindows()
