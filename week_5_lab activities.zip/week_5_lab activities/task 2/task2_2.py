imimport cv2

# first image
img1 = cv2.imread('/Users/siabahl/Desktop/Assets/Insects/1_Gammar 2021_1_2021_06_03-13-19-23-879.PNG')

# second image (modified from Task 2_6)
img2 = cv2.imread('/Users/siabahl/Desktop/Assets/modified.png')

# resize second image
img2_resized = cv2.resize(img2, (img1.shape[1], img1.shape[0]))

# blend
blended = cv2.addWeighted(img1, 0.6, img2_resized, 0.4, 0)

# show
cv2.imshow("Blended Image", blended)

cv2.waitKey(0)
cv2.destroyAllWindows()
