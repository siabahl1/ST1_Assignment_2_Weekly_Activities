import cv2
import numpy as np

# load image
image = cv2.imread('/Users/siabahl/Desktop/Assets/Insects/1_Gammar 2021_1_2021_06_03-13-19-23-879.PNG')

# invert colours
inverted = 255 - image

# combine images side by side
combined = np.hstack((image, inverted))

# show result
cv2.imshow("Original vs Inverted", combined)

cv2.waitKey(0)
cv2.destroyAllWindows()
