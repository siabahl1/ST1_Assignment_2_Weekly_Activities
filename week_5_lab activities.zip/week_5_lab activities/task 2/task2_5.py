import cv2

# load image
image = cv2.imread('/Users/siabahl/Desktop/Assets/Insects/1_Gammar 2021_1_2021_06_03-13-19-23-879.PNG')

# make a copy (important)
output = image.copy()

# draw red circle (BGR → red = (0,0,255))
cv2.circle(output, (100, 100), 50, (0, 0, 255), 3)

# show image
cv2.imshow("Circle Image", output)

cv2.waitKey(0)
cv2.destroyAllWindows()
