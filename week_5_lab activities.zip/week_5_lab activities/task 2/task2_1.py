import cv2

# load image
image = cv2.imread('/Users/siabahl/Desktop/Assets/Insects/1_Gammar 2021_1_2021_06_03-13-19-23-879.PNG')

# check if image loaded
if image is None:
    print("Error: Image not found")
else:
    print("Image loaded successfully")

    cv2.imshow("Original Image", image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
