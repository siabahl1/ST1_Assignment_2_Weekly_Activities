import cv2

# load image
image = cv2.imread('/Users/siabahl/Desktop/Assets/Insects/1_Gammar 2021_1_2021_06_03-13-19-23-879.PNG')

# convert to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# save image
cv2.imwrite('gray_image.png', gray)

# show image
cv2.imshow("Grayscale Image", gray)

cv2.waitKey(0)
cv2.destroyAllWindows()
