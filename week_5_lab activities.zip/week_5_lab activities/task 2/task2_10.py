import cv2

# load image
image = cv2.imread('/Users/siabahl/Desktop/Week_4_Lab_Activities 2/1_Gammar 2021_1_2021_06_03-13-19-23-856.PNG')

# convert BGR to HSV
hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

# split channels
h, s, v = cv2.split(hsv)

# show each channel
cv2.imshow("Hue Channel", h)
cv2.imshow("Saturation Channel", s)
cv2.imshow("Value Channel", v)

cv2.waitKey(0)
cv2.destroyAllWindows()
