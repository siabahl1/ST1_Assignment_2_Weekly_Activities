import cv2

# image 1
img1 = cv2.imread('/Users/siabahl/Desktop/Week_4_Lab_Activities 2/1_Gammar 2021_1_2021_06_03-13-19-23-856.PNG')

# image 2
img2 = cv2.imread('/Users/siabahl/Desktop/Week_4_Lab_Activities 2/cat.jpg')

# check
if img1 is None:
    print("img1 not found")
if img2 is None:
    print("img2 not found")

# resize second image
img2_resized = cv2.resize(img2, (img1.shape[1], img1.shape[0]))

# blend
blended = cv2.addWeighted(img1, 0.6, img2_resized, 0.4, 0)

# show
cv2.imshow("Blended Image", blended)
cv2.waitKey(0)
cv2.destroyAllWindows()
