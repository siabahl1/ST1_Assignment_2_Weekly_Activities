import cv2

# image 1
img1 = cv2.imread('/Users/siabahl/Desktop/Week_4_Lab_Activities 2/1_Gammar 2021_1_2021_06_03-13-19-23-856.PNG')

# image 2
img2 = cv2.imread('/Users/siabahl/Desktop/Week_4_Lab_Activities 2/cat.jpg')

# resize second image to match first
img2_resized = cv2.resize(img2, (img1.shape[1], img1.shape[0]))

# addition and subtraction
added = cv2.add(img1, img2_resized)
subtracted = cv2.subtract(img1, img2_resized)

# show results
cv2.imshow("Added Image", added)
cv2.imshow("Subtracted Image", subtracted)

cv2.waitKey(0)
cv2.destroyAllWindows()
